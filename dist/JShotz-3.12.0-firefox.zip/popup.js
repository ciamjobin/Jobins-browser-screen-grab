const statusEl = document.getElementById('status');
const toggleEl = document.getElementById('toggle');
const captureNowEl = document.getElementById('captureNow');
const captureLaterEl = document.getElementById('captureLater');
const exportPdfNowEl = document.getElementById('exportPdfNow');
const captureListEl = document.getElementById('captureList');
const settingsEl = document.querySelector('.settings');
const mainActionsEl = document.getElementById('mainActions');
const confirmEl = document.getElementById('confirm');
const filenamePromptEl = document.getElementById('filenamePrompt');
const deleteConfirmEl = document.getElementById('deleteConfirm');
const pdfFilenameEl = document.getElementById('pdfFilename');
const shortcutHintEl = document.getElementById('shortcutHint');
const selectAllCapturesEl = document.getElementById('selectAllCaptures');
const captureSelectionSummaryEl = document.getElementById('captureSelectionSummary');
const saveWithNameEl = document.getElementById('saveWithName');

let awaitingChoice = false;
let pendingExportOnly = false;
let selectedCaptureSequences = new Set();
let knownCaptureSequences = new Set();
let captureSelectionSessionId = null;
let currentCaptures = [];
let currentSettings = {};

const controls = {
  captureMode: document.getElementById('captureMode'),
  captureOnClick: document.getElementById('captureOnClick'),
  captureOnScroll: document.getElementById('captureOnScroll'),
  stampTimestamp: document.getElementById('stampTimestamp'),
  fullPage: document.getElementById('fullPage'),
  savePng: document.getElementById('savePng'),
  savePdf: document.getElementById('savePdf')
};

function send(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

function readSettings() {
  return {
    captureMode: controls.captureMode.value,
    captureOnClick: controls.captureOnClick.checked,
    captureOnScroll: controls.captureOnScroll.checked,
    stampTimestamp: controls.stampTimestamp.checked,
    fullPage: controls.fullPage.checked,
    savePng: controls.savePng.checked,
    savePdf: controls.savePdf.checked
  };
}

function captureSequences(captures = currentCaptures) {
  return captures
    .map((capture) => capture.sequence)
    .filter((sequence) => Number.isSafeInteger(sequence) && sequence > 0);
}

function syncCaptureSelection(sessionId, captures) {
  const sequences = new Set(captureSequences(captures));
  if (sessionId !== captureSelectionSessionId) {
    captureSelectionSessionId = sessionId;
    selectedCaptureSequences = new Set(sequences);
  } else {
    for (const sequence of sequences) {
      if (!knownCaptureSequences.has(sequence)) selectedCaptureSequences.add(sequence);
    }
    selectedCaptureSequences = new Set(
      [...selectedCaptureSequences].filter((sequence) => sequences.has(sequence))
    );
  }
  knownCaptureSequences = sequences;
  currentCaptures = captures;
}

function selectedCaptureSequenceList() {
  return captureSequences().filter((sequence) => selectedCaptureSequences.has(sequence));
}

function updateCaptureSelectionControls() {
  const total = captureSequences().length;
  const selected = selectedCaptureSequenceList().length;
  selectAllCapturesEl.disabled = !total;
  selectAllCapturesEl.checked = total > 0 && selected === total;
  selectAllCapturesEl.indeterminate = false;
  captureSelectionSummaryEl.textContent = total ? `${selected} of ${total} selected for PDF.` : '';

  const needsSelection = pendingExportOnly || currentSettings.savePdf !== false;
  saveWithNameEl.disabled =
    !filenamePromptEl.hidden && needsSelection && total > 0 && selected === 0;
}

function renderCaptures(captures) {
  captureListEl.replaceChildren();

  if (!captures.length) {
    const empty = document.createElement('li');
    empty.className = 'empty';
    empty.textContent = 'No captures yet.';
    captureListEl.append(empty);
    updateCaptureSelectionControls();
    return;
  }

  // Newest first, and build nodes with textContent so untrusted page titles can't inject markup.
  for (const capture of [...captures].reverse()) {
    const item = document.createElement('li');

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = selectedCaptureSequences.has(capture.sequence);
    checkbox.setAttribute('aria-label', `Include screenshot ${capture.sequence} in PDF`);
    checkbox.addEventListener('change', () => {
      if (checkbox.checked) {
        selectedCaptureSequences.add(capture.sequence);
      } else {
        selectedCaptureSequences.delete(capture.sequence);
      }
      updateCaptureSelectionControls();
    });

    const title = document.createElement('span');
    title.className = 'capture-title';
    title.textContent = `${capture.sequence}. ${capture.title || capture.url}`;
    title.title = capture.url || '';

    const meta = document.createElement('span');
    meta.className = 'capture-meta';
    meta.textContent = `${new Date(capture.capturedAt).toLocaleTimeString()} · ${capture.reason}`;

    const selection = document.createElement('label');
    selection.className = 'capture-select';
    selection.append(checkbox, title);
    item.append(selection, meta);
    captureListEl.append(item);
  }
  updateCaptureSelectionControls();
}

function render(state) {
  const recording = Boolean(state?.recording);
  const settings = state?.settings ?? {};
  currentSettings = settings;
  syncCaptureSelection(state?.sessionId ?? null, state?.captures ?? []);

  // Polling must not steal a control the user is currently interacting with.
  const apply = (control, assign) => {
    if (document.activeElement !== control) assign();
  };
  apply(controls.captureMode, () => (controls.captureMode.value = settings.captureMode ?? 'tab'));
  apply(controls.captureOnClick, () => (controls.captureOnClick.checked = settings.captureOnClick !== false));
  apply(controls.captureOnScroll, () => (controls.captureOnScroll.checked = settings.captureOnScroll !== false));
  apply(controls.stampTimestamp, () => (controls.stampTimestamp.checked = settings.stampTimestamp !== false));
  apply(controls.fullPage, () => (controls.fullPage.checked = settings.fullPage !== false));
  apply(controls.savePng, () => (controls.savePng.checked = settings.savePng !== false));
  apply(controls.savePdf, () => (controls.savePdf.checked = settings.savePdf !== false));
  settingsEl.classList.toggle('locked', recording);
  shortcutHintEl.hidden = controls.captureMode.value !== 'screen';

  const problem = state?.error || state?.lastError;
  if (problem) {
    statusEl.textContent = problem;
    statusEl.className = 'status error';
  } else if (recording) {
    const api = settings.captureApi ? ` \u00b7 ${state.apiSeen} API call(s)` : '';
    statusEl.textContent = `Recording \u00b7 ${state.sequence} screenshot(s)${api}`;
    statusEl.className = 'status recording';
  } else {
    statusEl.textContent = 'Idle';
    statusEl.className = 'status idle';
  }

  toggleEl.textContent = recording ? 'Stop recording' : 'Start recording';
  toggleEl.classList.toggle('stop', recording);
  captureNowEl.disabled = !recording;
  captureLaterEl.disabled = !recording;
  exportPdfNowEl.disabled = !recording || !state?.captures?.length;

  renderCaptures(currentCaptures);
}

async function refresh() {
  // Polling must not dismiss the keep-or-delete prompt out from under the user.
  if (awaitingChoice) return;
  render(await send('GET_STATE').catch(() => null));
}

toggleEl.addEventListener('click', async () => {
  const state = await send('GET_STATE');
  if (state.recording) {
    awaitingChoice = true;
    mainActionsEl.hidden = true;
    confirmEl.hidden = false;
    filenamePromptEl.hidden = true;
    deleteConfirmEl.hidden = true;
    return;
  }
  render(await send('START', { settings: readSettings() }));
});

async function finishRecording(keepFiles, pdfFilename) {
  confirmEl.hidden = true;
  filenamePromptEl.hidden = true;
  deleteConfirmEl.hidden = true;
  mainActionsEl.hidden = false;
  awaitingChoice = false;
  toggleEl.disabled = true;
  statusEl.textContent = keepFiles
    ? 'Finishing up \u2014 writing files and opening the folder\u2026'
    : 'Deleting captured files\u2026';
  const payload = { keepFiles, pdfFilename };
  if (keepFiles && currentSettings.savePdf !== false) {
    payload.selectedSequences = selectedCaptureSequenceList();
  }
  render(await send('STOP', payload));
  toggleEl.disabled = false;
}

async function exportPdfNow(pdfFilename) {
  filenamePromptEl.hidden = true;
  mainActionsEl.hidden = false;
  awaitingChoice = false;
  statusEl.textContent = 'Writing checkpoint PDF\u2026';
  render(await send('EXPORT_PDF_NOW', {
    pdfFilename,
    selectedSequences: selectedCaptureSequenceList()
  }));
}

document.getElementById('keepYes').addEventListener('click', async () => {
  const state = await send('GET_STATE');
  render(state);
  pendingExportOnly = false;
  pdfFilenameEl.value = `${state.sessionId || 'JShotz-session'}.pdf`;
  confirmEl.hidden = true;
  filenamePromptEl.hidden = false;
  updateCaptureSelectionControls();
  pdfFilenameEl.focus();
  pdfFilenameEl.select();
});

document.getElementById('keepNo').addEventListener('click', () => {
  confirmEl.hidden = true;
  deleteConfirmEl.hidden = false;
});
document.getElementById('filenameCancel').addEventListener('click', () => {
  filenamePromptEl.hidden = true;
  if (pendingExportOnly) {
    mainActionsEl.hidden = false;
    awaitingChoice = false;
  } else {
    confirmEl.hidden = false;
  }
});
document.getElementById('saveWithName').addEventListener('click', () => {
  const needsSelection = pendingExportOnly || currentSettings.savePdf !== false;
  if (needsSelection && currentCaptures.length && !selectedCaptureSequenceList().length) {
    statusEl.textContent = 'Select at least one screenshot for the PDF.';
    statusEl.className = 'status error';
    return;
  }
  if (pendingExportOnly) {
    exportPdfNow(pdfFilenameEl.value);
  } else {
    finishRecording(true, pdfFilenameEl.value);
  }
});
document.getElementById('deleteConfirmYes').addEventListener('click', () => finishRecording(false));
document.getElementById('deleteConfirmNo').addEventListener('click', () => {
  deleteConfirmEl.hidden = true;
  confirmEl.hidden = false;
});

document.getElementById('createPdfLater').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('pdf-import.html') });
});

captureNowEl.addEventListener('click', async () => {
  render(await send('CAPTURE_NOW'));
});

exportPdfNowEl.addEventListener('click', async () => {
  const state = await send('GET_STATE');
  render(state);
  pendingExportOnly = true;
  awaitingChoice = true;
  pdfFilenameEl.value = `${state.sessionId || 'JShotz-session'}_checkpoint.pdf`;
  mainActionsEl.hidden = true;
  filenamePromptEl.hidden = false;
  updateCaptureSelectionControls();
  pdfFilenameEl.focus();
  pdfFilenameEl.select();
});

selectAllCapturesEl.addEventListener('change', () => {
  selectedCaptureSequences = selectAllCapturesEl.checked
    ? new Set(captureSequences())
    : new Set();
  renderCaptures(currentCaptures);
});

// The popup closes as soon as focus moves to DevTools, so the countdown lives in the background.
captureLaterEl.addEventListener('click', async () => {
  render(await send('CAPTURE_LATER'));
  statusEl.textContent = 'Capturing in 5s \u2014 click into DevTools now\u2026';
  window.close();
});

for (const control of Object.values(controls)) {
  control.addEventListener('change', () => {
    shortcutHintEl.hidden = controls.captureMode.value !== 'screen';
    send('SET_SETTINGS', { settings: readSettings() });
  });
}

// Chrome closes the popup when the share picker opens, so re-sync on open and while visible.
refresh();
setInterval(refresh, 1000);
