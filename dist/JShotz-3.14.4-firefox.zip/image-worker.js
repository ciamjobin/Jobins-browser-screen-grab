// Pure canvas work, shared by the Chromium offscreen document and the Firefox background page.
// Must not touch any extension API so both hosts can load it.

function drawCapturedTitleBar(canvas, title, url) {
  const ctx = canvas.getContext('2d');
  const height = titleBarHeight(canvas.width);
  const pad = Math.max(14, Math.round(canvas.width / 95));
  const titleSize = Math.max(14, Math.round(canvas.width / 95));
  const urlSize = Math.max(10, Math.round(canvas.width / 135));

  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, canvas.width, height);
  ctx.fillStyle = '#e5e7eb';
  ctx.fillRect(0, height - 1, canvas.width, 1);
  ctx.fillStyle = '#8b0000';
  ctx.fillRect(0, 0, canvas.width, 4);

  ctx.textBaseline = 'top';
  ctx.textAlign = 'left';
  ctx.font = `700 ${titleSize}px "Segoe UI", Arial, sans-serif`;
  ctx.fillStyle = '#111827';
  ctx.fillText(clipText(ctx, title || 'Untitled page', canvas.width - pad * 2), pad, 10);

  ctx.font = `${urlSize}px "Segoe UI", Arial, sans-serif`;
  ctx.fillStyle = '#4b5563';
  ctx.fillText(clipText(ctx, url || '', canvas.width - pad * 2), pad, 12 + titleSize + 4);
}

function titleBarHeight(width) {
  return Math.max(48, Math.round(width / 24));
}

function clipText(ctx, text, maxWidth) {
  const value = String(text ?? '').replace(/\s+/g, ' ').trim();
  if (ctx.measureText(value).width <= maxWidth) return value;

  let clipped = value;
  while (clipped.length > 1 && ctx.measureText(`${clipped}...`).width > maxWidth) {
    clipped = clipped.slice(0, -1);
  }
  return `${clipped}...`;
}

function clamp(value, lower, upper) {
  return Math.min(upper, Math.max(lower, value));
}

// Capture-visible-tab returns bitmap pixels while dialog geometry arrives in CSS viewport pixels.
// Keep a small surrounding gutter so the modal still reads as a complete UI surface in the export.
function modalCropRect(modal, bitmapWidth, bitmapHeight) {
  if (!modal?.compact) return null;
  const numbers = [
    modal.left,
    modal.top,
    modal.width,
    modal.height,
    modal.viewportWidth,
    modal.viewportHeight,
    bitmapWidth,
    bitmapHeight
  ].map(Number);
  if (!numbers.every(Number.isFinite)) return null;

  const [left, top, width, height, viewportWidth, viewportHeight] = numbers;
  if (width < 2 || height < 2 || viewportWidth < 2 || viewportHeight < 2 || bitmapWidth < 2 || bitmapHeight < 2) {
    return null;
  }

  const scaleX = bitmapWidth / viewportWidth;
  const scaleY = bitmapHeight / viewportHeight;
  if (!Number.isFinite(scaleX) || !Number.isFinite(scaleY) || scaleX <= 0 || scaleY <= 0) return null;

  const gutter = Math.min(16, Math.max(8, Math.round(Math.min(width, height) * 0.035)));
  const startX = Math.floor(clamp(left - gutter, 0, viewportWidth) * scaleX);
  const startY = Math.floor(clamp(top - gutter, 0, viewportHeight) * scaleY);
  const endX = Math.ceil(clamp(left + width + gutter, 0, viewportWidth) * scaleX);
  const endY = Math.ceil(clamp(top + height + gutter, 0, viewportHeight) * scaleY);
  const x = clamp(startX, 0, bitmapWidth);
  const y = clamp(startY, 0, bitmapHeight);
  const right = clamp(endX, x, bitmapWidth);
  const bottom = clamp(endY, y, bitmapHeight);
  if (right - x < 2 || bottom - y < 2) return null;
  return { x, y, width: right - x, height: bottom - y };
}

function fullPageCropRect(ctx, width, height) {
  if (width < 32 || height < 32) return null;
  const { data } = ctx.getImageData(0, 0, width, height);
  const sampleStepX = Math.max(1, Math.floor(width / 400));
  const sampleStepY = Math.max(1, Math.floor(height / 800));
  const colorCounts = new Map();

  for (let y = Math.max(0, height - 8); y < height; y += 1) {
    for (let x = 0; x < width; x += sampleStepX) {
      const index = (y * width + x) * 4;
      const key = `${data[index] >> 3},${data[index + 1] >> 3},${data[index + 2] >> 3}`;
      colorCounts.set(key, (colorCounts.get(key) || 0) + 1);
    }
  }

  const backgroundKey = [...colorCounts.entries()]
    .filter(([key]) => key.split(',').every((value) => Number(value) >= 27))
    .sort((left, right) => right[1] - left[1])[0]?.[0];
  if (!backgroundKey) return null;
  const background = backgroundKey.split(',').map((value) => Number(value) << 3);
  const differs = (index) =>
    Math.abs(data[index] - background[0]) > 12 ||
    Math.abs(data[index + 1] - background[1]) > 12 ||
    Math.abs(data[index + 2] - background[2]) > 12;

  const rowSamples = Math.ceil(width / sampleStepX);
  let bottom = height;
  for (let y = height - 1; y >= 0; y -= 1) {
    let painted = 0;
    for (let x = 0; x < width; x += sampleStepX) {
      if (differs((y * width + x) * 4)) painted += 1;
    }
    if (painted > rowSamples * 0.03) {
      bottom = y + 1;
      break;
    }
  }

  const columnSamples = Math.ceil(bottom / sampleStepY);
  let right = width;
  let paintedColumnRun = 0;
  for (let x = width - 1; x >= 0; x -= 1) {
    let painted = 0;
    for (let y = 0; y < bottom; y += sampleStepY) {
      if (differs((y * width + x) * 4)) painted += 1;
    }
    if (painted > columnSamples * 0.01) {
      paintedColumnRun += 1;
      if (paintedColumnRun >= 4) {
        right = x + paintedColumnRun;
        break;
      }
    } else {
      paintedColumnRun = 0;
    }
  }

  const padding = Math.max(16, Math.min(48, Math.round(Math.min(width, height) / 50)));
  const cropWidth = Math.min(width, right + padding);
  const cropHeight = Math.min(height, bottom + padding);
  if (cropWidth >= width && cropHeight >= height) return null;
  if (cropWidth < 32 || cropHeight < 32) return null;
  return { x: 0, y: 0, width: cropWidth, height: cropHeight };
}

function paintedContentRatio(ctx, width, height) {
  if (width < 2 || height < 2) return 0;
  const stepX = Math.max(1, Math.floor(width / 160));
  const stepY = Math.max(1, Math.floor(height / 120));
  const { data } = ctx.getImageData(0, 0, width, height);
  const corners = [
    0,
    (width - 1) * 4,
    ((height - 1) * width) * 4,
    (height * width - 1) * 4
  ];
  const background = [0, 1, 2].map((channel) =>
    Math.round(corners.reduce((sum, index) => sum + data[index + channel], 0) / corners.length)
  );
  let painted = 0;
  let samples = 0;
  for (let y = 0; y < height; y += stepY) {
    for (let x = 0; x < width; x += stepX) {
      const index = (y * width + x) * 4;
      if (
        Math.abs(data[index] - background[0]) > 18 ||
        Math.abs(data[index + 1] - background[1]) > 18 ||
        Math.abs(data[index + 2] - background[2]) > 18
      ) painted += 1;
      samples += 1;
    }
  }
  return samples ? painted / samples : 0;
}

async function scoreCapture(dataUrl) {
  let bitmap;
  let canvas;
  try {
    bitmap = await createImageBitmap(await (await fetch(dataUrl)).blob());
    canvas = document.createElement('canvas');
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(bitmap, 0, 0);
    return { paintedRatio: paintedContentRatio(ctx, bitmap.width, bitmap.height) };
  } finally {
    bitmap?.close();
    if (canvas) {
      canvas.width = 1;
      canvas.height = 1;
    }
  }
}

const TABLE_FONT = 14;
const TABLE_LINE = 19;
const TABLE_PAD = 10;
const TABLE_TITLE_HEIGHT = 34;
const TABLE_HEADER_HEIGHT = 30;

const TABLE_COLUMNS = [
  { title: 'API Name', key: 'name', ratio: 0.2 },
  { title: 'Origin and Referer', key: 'origin', ratio: 0.22 },
  { title: 'Payload', key: 'payload', ratio: 0.28 },
  { title: 'Response', key: 'response', ratio: 0.3 }
];

function layoutApiTable(rows, width) {
  const ctx = document.createElement('canvas').getContext('2d');
  ctx.font = `${TABLE_FONT}px Consolas, "Courier New", monospace`;

  let x = TABLE_PAD;
  const columns = TABLE_COLUMNS.map((column) => {
    const columnWidth = (width - TABLE_PAD * 2) * column.ratio;
    const laid = { ...column, x, width: columnWidth };
    x += columnWidth;
    return laid;
  });

  const laidRows = rows.map((row) => {
    const cells = columns.map((column) => wrapLines(ctx, row[column.key], column.width - TABLE_PAD * 2));
    const lineCount = Math.max(...cells.map((lines) => lines.length));
    return { cells, outcome: row.outcome, height: lineCount * TABLE_LINE + TABLE_PAD * 2 };
  });

  const height =
    TABLE_TITLE_HEIGHT +
    TABLE_HEADER_HEIGHT +
    laidRows.reduce((total, row) => total + row.height, 0) +
    TABLE_PAD * 2;

  return { columns, rows: laidRows, height };
}

function drawApiTable(ctx, table, top, width) {
  ctx.textBaseline = 'top';
  ctx.textAlign = 'left';

  ctx.fillStyle = '#f5f7fa';
  ctx.fillRect(0, top, width, table.height);
  ctx.strokeStyle = '#cbd2d9';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, top + 0.5);
  ctx.lineTo(width, top + 0.5);
  ctx.stroke();

  ctx.fillStyle = '#1f2933';
  ctx.font = '700 16px "Segoe UI", Arial, sans-serif';
  ctx.fillText('API calls in this step', TABLE_PAD, top + TABLE_PAD);

  let y = top + TABLE_TITLE_HEIGHT;

  ctx.fillStyle = '#e4e7eb';
  ctx.fillRect(0, y, width, TABLE_HEADER_HEIGHT);
  ctx.fillStyle = '#243b53';
  ctx.font = '700 14px "Segoe UI", Arial, sans-serif';
  for (const column of table.columns) {
    ctx.fillText(column.title, column.x + TABLE_PAD, y + 7);
  }
  y += TABLE_HEADER_HEIGHT;

  ctx.font = `${TABLE_FONT}px Consolas, "Courier New", monospace`;
  const bodyTop = y;
  for (const row of table.rows) {
    if (row.outcome !== 'success') {
      ctx.fillStyle = '#fff59d';
      for (const index of [0, 3]) {
        const column = table.columns[index];
        ctx.fillRect(column.x, y, column.width, row.height);
      }
    }

    ctx.strokeStyle = '#cbd2d9';
    ctx.beginPath();
    ctx.moveTo(0, y + 0.5);
    ctx.lineTo(width, y + 0.5);
    ctx.stroke();

    // A red rail marks failed calls without needing an extra column.
    ctx.fillStyle = row.outcome === 'success' ? '#2e7d32' : '#c62828';
    ctx.fillRect(0, y, 4, row.height);

    row.cells.forEach((lines, index) => {
      const column = table.columns[index];
      ctx.fillStyle = index === 0 ? '#1f2933' : '#243b53';
      lines.forEach((line, lineIndex) => {
        ctx.fillText(line, column.x + TABLE_PAD, y + TABLE_PAD + lineIndex * TABLE_LINE);
      });
    });

    y += row.height;
  }

  ctx.strokeStyle = '#cbd2d9';
  ctx.beginPath();
  ctx.moveTo(0, y + 0.5);
  ctx.lineTo(width, y + 0.5);
  for (const column of table.columns) {
    ctx.moveTo(Math.round(column.x) + 0.5, bodyTop - TABLE_HEADER_HEIGHT);
    ctx.lineTo(Math.round(column.x) + 0.5, y);
  }
  ctx.stroke();
}

async function processCapture({
  dataUrl,
  wantPng,
  wantJpeg,
  apiRows,
  titleBar,
  jpegQuality,
  modal,
  trimBlankMargins
}) {
  let bitmap;
  let sourceCanvas;
  let imageCanvas;
  let outputCanvas;
  try {
    const blob = await (await fetch(dataUrl)).blob();
    bitmap = await createImageBitmap(blob);
    let crop = modalCropRect(modal, bitmap.width, bitmap.height);
    if (!crop && trimBlankMargins) {
      sourceCanvas = document.createElement('canvas');
      sourceCanvas.width = bitmap.width;
      sourceCanvas.height = bitmap.height;
      const sourceCtx = sourceCanvas.getContext('2d', { willReadFrequently: true });
      sourceCtx.drawImage(bitmap, 0, 0);
      crop = fullPageCropRect(sourceCtx, bitmap.width, bitmap.height);
    }
    const imageWidth = crop?.width || bitmap.width;
    const imageHeight = crop?.height || bitmap.height;
    const titleHeight = titleBar ? titleBarHeight(imageWidth) : 0;

    const table = apiRows?.length ? layoutApiTable(apiRows, imageWidth) : null;
    imageCanvas = document.createElement('canvas');
    imageCanvas.width = imageWidth;
    imageCanvas.height = imageHeight + titleHeight;

    const imageCtx = imageCanvas.getContext('2d');
    imageCtx.fillStyle = '#ffffff';
    imageCtx.fillRect(0, 0, imageCanvas.width, imageCanvas.height);
    if (titleBar) drawCapturedTitleBar(imageCanvas, titleBar.title, titleBar.url);
    if (crop) {
      imageCtx.drawImage(bitmap, crop.x, crop.y, crop.width, crop.height, 0, titleHeight, imageWidth, imageHeight);
    } else {
      imageCtx.drawImage(bitmap, 0, titleHeight);
    }

    if (table) {
      outputCanvas = document.createElement('canvas');
      outputCanvas.width = imageCanvas.width;
      outputCanvas.height = imageCanvas.height + table.height;

      const ctx = outputCanvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, outputCanvas.width, outputCanvas.height);
      ctx.drawImage(imageCanvas, 0, 0);
      drawApiTable(ctx, table, imageCanvas.height, outputCanvas.width);
    }

    const quality = Number.isFinite(jpegQuality) ? Math.max(0, Math.min(1, jpegQuality)) : 0.82;
    return {
      pngDataUrl: wantPng ? (outputCanvas || imageCanvas).toDataURL('image/png') : null,
      jpeg: wantJpeg
        ? {
            base64: imageCanvas.toDataURL('image/jpeg', quality).split(',')[1],
            width: imageCanvas.width,
            height: imageCanvas.height
          }
        : null
    };
  } finally {
    bitmap?.close();
    if (sourceCanvas) {
      sourceCanvas.width = 1;
      sourceCanvas.height = 1;
    }
    if (imageCanvas) {
      imageCanvas.width = 1;
      imageCanvas.height = 1;
    }
    if (outputCanvas) {
      outputCanvas.width = 1;
      outputCanvas.height = 1;
    }
  }
}

function wrapLines(ctx, text, maxWidth) {
  const lines = [];
  const pushMeasured = (value) => {
    let current = '';
    for (const char of value) {
      const candidate = current + char;
      if (current && ctx.measureText(candidate).width > maxWidth) {
        lines.push(current);
        current = char;
      } else {
        current = candidate;
      }
    }
    return current;
  };

  for (const rawLine of String(text ?? '').split('\n')) {
    if (!rawLine) {
      lines.push('');
      continue;
    }
    let current = '';
    for (const word of rawLine.split(/(\s+)/)) {
      const candidate = current + word;
      if (ctx.measureText(candidate).width > maxWidth && current) {
        lines.push(current.trimEnd());
        current = pushMeasured(word.trimStart());
      } else {
        current = ctx.measureText(word).width > maxWidth ? pushMeasured(candidate) : candidate;
      }
    }
    if (current || !lines.length) lines.push(current);
  }
  return lines;
}

const handlers = {
  OFFSCREEN_PING: () => ({ ok: true }),
  OFFSCREEN_SCORE_CAPTURE: (message) => scoreCapture(message.dataUrl),
  OFFSCREEN_PROCESS: (message) => processCapture(message)
};

export { processCapture, handlers, modalCropRect, fullPageCropRect, paintedContentRatio };
