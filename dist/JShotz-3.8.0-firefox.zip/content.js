const INTERACTIVE_SELECTOR = [
  'button',
  '[role="button"]',
  'input[type="submit"]',
  'input[type="button"]',
  'input[type="reset"]',
  'input[type="checkbox"]',
  'input[type="radio"]',
  '[role="checkbox"]',
  '[role="radio"]',
  '[role="switch"]',
  '[role="tab"]',
  'summary',
  '[type="submit"]'
].join(',');

const OPTION_SELECTOR = [
  '[role="option"]',
  '[role="menuitem"]',
  '[role="menuitemradio"]',
  '[role="menuitemcheckbox"]',
  '[role="treeitem"]',
  'option'
].join(',');

const LIST_SELECTOR = [
  '[role="listbox"]',
  '[role="menu"]',
  '[role="tree"]',
  '[role="grid"]',
  '[role="combobox"]',
  'datalist'
].join(',');

const DIALOG_SELECTOR = ['dialog', '[role="dialog"]', '[role="alertdialog"]'].join(',');

// The list whose opened state was already captured; further poking or scrolling inside adds nothing.
let capturedList = null;
let lastSent = { key: '', at: 0 };
let editTimer = 0;
let selectionTimer = 0;
let dialogTimer = 0;
let scrollTimer = 0;
let suppressScrollUntil = 0;
const scrollAnchors = new WeakMap();
const capturedDialogs = new WeakSet();

function describe(element) {
  const candidates = [
    element.getAttribute?.('aria-label'),
    element.innerText,
    element.value,
    element.getAttribute?.('title'),
    element.name,
    element.id
  ];

  for (const candidate of candidates) {
    const text = (candidate || '').trim().replace(/\s+/g, ' ');
    if (text) return text.slice(0, 80);
  }
  return element.tagName ? element.tagName.toLowerCase() : 'element';
}

function requestCapture(reason, label) {
  const key = `${reason}:${label}`;
  const now = Date.now();
  if (key === lastSent.key && now - lastSent.at < 800) return;
  lastSent = { key, at: now };

  // A full-page shot resizes the layout viewport, which moves the page; that must not read as the
  // user scrolling.
  if (reason !== 'scrolled') suppressScrollUntil = now + 2500;

  chrome.runtime.sendMessage({ type: 'CLICK_CAPTURE', reason, label }).catch(() => {
    /* Background may be asleep or recording stopped; nothing to do. */
  });
}

const SETTLE_QUIET_MS = 400;
const SETTLE_MAX_WAIT_MS = 8000;
const BUSY_SELECTOR = [
  '[aria-busy="true"]',
  '[class*="spinner" i]',
  '[class*="loading" i]',
  '[class*="loader" i]'
].join(',');
const BUSY_TEXT_PATTERN = /please\s+wait|loading|retrieving/i;

// A button click on a client-rendered page often swaps in a loading spinner before the real next
// screen appears; capturing right away would just record the spinner. Waits until the DOM stops
// actively changing (or a hard cap is reached, in case something keeps animating indefinitely).
function waitForQuiet(quietMs, maxWaitMs) {
  return new Promise((resolve) => {
    let settleTimer = 0;
    const finish = () => {
      observer.disconnect();
      clearTimeout(settleTimer);
      clearTimeout(hardStop);
      resolve();
    };
    const observer = new MutationObserver(() => {
      clearTimeout(settleTimer);
      settleTimer = setTimeout(finish, quietMs);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
    settleTimer = setTimeout(finish, quietMs);
    const hardStop = setTimeout(finish, maxWaitMs);
  });
}

// A pure CSS spinner (no DOM mutations while it spins) looks "quiet" to the observer above
// immediately, even though the page is still loading. This catches that case by name: if a visible
// busy indicator or "please wait" style message is still on screen, keep polling briefly instead of
// capturing it, up to the same overall cap.
function looksBusy() {
  if (document.querySelector(BUSY_SELECTOR)) return true;
  const text = document.body?.innerText || '';
  return BUSY_TEXT_PATTERN.test(text.slice(0, 500));
}

async function requestCaptureAfterSettle(reason, label) {
  const deadline = Date.now() + SETTLE_MAX_WAIT_MS;
  await waitForQuiet(SETTLE_QUIET_MS, SETTLE_MAX_WAIT_MS);
  while (looksBusy() && Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 300));
  }
  requestCapture(reason, label);
}

function describeEditedField(element) {
  if (element instanceof HTMLInputElement && element.type === 'password') {
    return `${describe(element)} edited`;
  }
  return `${describe(element)} edited`;
}

function requestEditCapture(element) {
  clearTimeout(editTimer);
  editTimer = setTimeout(() => requestCapture('field-edited', describeEditedField(element)), 700);
}

function selectedTextFromActiveElement() {
  const active = document.activeElement;
  if (active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement) {
    const start = active.selectionStart ?? 0;
    const end = active.selectionEnd ?? 0;
    return end > start ? active.value.slice(start, end) : '';
  }
  return window.getSelection()?.toString() || '';
}

function requestSelectionCapture() {
  clearTimeout(selectionTimer);
  selectionTimer = setTimeout(() => {
    const text = selectedTextFromActiveElement().trim().replace(/\s+/g, ' ');
    if (text) requestCapture('text-selected', text.slice(0, 80));
  }, 500);
}

function isVisible(element) {
  if (element.hasAttribute('hidden') || element.getAttribute('aria-hidden') === 'true') return false;
  const rect = element.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

// A modal can be opened by a control we do not recognise, so watch for the dialog itself appearing.
function scanForDialogs() {
  clearTimeout(dialogTimer);
  dialogTimer = setTimeout(() => {
    for (const dialog of document.querySelectorAll(DIALOG_SELECTOR)) {
      if (capturedDialogs.has(dialog) || !isVisible(dialog)) continue;
      capturedDialogs.add(dialog);
      requestCapture('dialog-opened', describe(dialog));
      return;
    }
  }, 350);
}

new MutationObserver(scanForDialogs).observe(document.documentElement, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ['open', 'hidden', 'aria-hidden', 'class', 'style']
});

function isManualShortcut(event) {
  return event.ctrlKey && event.altKey && !event.shiftKey && event.key?.toLowerCase() === 'q';
}

window.addEventListener(
  'keydown',
  (event) => {
    if (!isManualShortcut(event)) return;
    event.preventDefault();
    event.stopPropagation();
    requestCapture('manual-hotkey', 'Ctrl+Alt+Q');
  },
  true
);

// Capture phase so we still see the click even if the handler stops propagation.
window.addEventListener(
  'click',
  (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    // Choosing an entry closes the list, so this is the selection worth keeping.
    const option = target.closest(OPTION_SELECTOR);
    if (option) {
      capturedList = null;
      requestCapture('selection', describe(option));
      return;
    }

    const list = target.closest(LIST_SELECTOR);
    if (list) {
      if (capturedList === list) return;
      capturedList = list;
      requestCapture('list-opened', describe(list));
      return;
    }

    const trigger = target.closest(INTERACTIVE_SELECTOR) || target.closest('a[href]');
    if (!trigger) return;

    const opensList = trigger.hasAttribute('aria-haspopup') || trigger.hasAttribute('aria-expanded');
    if (opensList) capturedList = null;

    // A button click on a client-rendered page often swaps in a loading spinner before the real
    // next screen appears; capturing immediately would just record the spinner. Waiting for the
    // page to stop actively changing catches the settled result instead.
    if (opensList) {
      requestCapture('list-opened', describe(trigger));
    } else {
      requestCaptureAfterSettle('click', describe(trigger));
    }
  },
  true
);

// Most of a screenful of scrolling is one new thing to see, so capture whenever the user has
// travelled that far and paused, and again when they land at the end. Capture phase because scroll
// events from inner panes do not bubble.
const SCROLL_STEP_RATIO = 0.6;
const SCROLL_END_SLACK = 4;
const SCROLL_MIN_TRAVEL = 40;

document.addEventListener(
  'scroll',
  (event) => {
    const target = event.target;
    const isDocument = target === document || target === document.documentElement || target === document.body;
    const scroller = isDocument ? document.documentElement : target;
    if (!isDocument && !(scroller instanceof Element)) return;

    const position = isDocument ? window.scrollY : scroller.scrollTop;
    const screenful = isDocument ? window.innerHeight : scroller.clientHeight;
    if (screenful < 200) return;

    const key = isDocument ? document.documentElement : scroller;
    if (!scrollAnchors.has(key)) scrollAnchors.set(key, position);
    if (Date.now() < suppressScrollUntil) {
      scrollAnchors.set(key, position);
      return;
    }

    const travelled = Math.abs(position - scrollAnchors.get(key));
    const limit = isDocument
      ? Math.max(document.documentElement.scrollHeight - window.innerHeight, 1)
      : Math.max(scroller.scrollHeight - scroller.clientHeight, 1);
    const atEnd = position >= limit - SCROLL_END_SLACK;

    if (travelled < screenful * SCROLL_STEP_RATIO && !(atEnd && travelled >= SCROLL_MIN_TRAVEL)) return;

    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => {
      const settled = isDocument ? window.scrollY : scroller.scrollTop;
      scrollAnchors.set(key, settled);
      const label =
        settled >= limit - SCROLL_END_SLACK
          ? 'end of page'
          : `${Math.round((settled / limit) * 100)}% down`;
      requestCapture('scrolled', label);
    }, 450);
  },
  true
);

// Native <select> options never fire click events, so the selection arrives as a change.
window.addEventListener(
  'change',
  (event) => {
    const element = event.target;
    if (element instanceof HTMLSelectElement) {
      const chosen = element.options[element.selectedIndex]?.text ?? element.value;
      requestCapture('selection', `${describe(element)} = ${chosen}`.slice(0, 80));
      return;
    }

    if (element instanceof HTMLInputElement && (element.type === 'checkbox' || element.type === 'radio')) {
      const state = element.checked ? 'checked' : 'unchecked';
      requestCapture('toggle', `${describe(element)} = ${state}`.slice(0, 80));
    }
  },
  true
);

window.addEventListener(
  'input',
  (event) => {
    const element = event.target;
    if (
      element instanceof HTMLInputElement ||
      element instanceof HTMLTextAreaElement ||
      element instanceof HTMLSelectElement ||
      element?.isContentEditable
    ) {
      requestEditCapture(element);
    }
  },
  true
);

document.addEventListener('selectionchange', requestSelectionCapture, true);
window.addEventListener('select', requestSelectionCapture, true);

// page-hook.js runs in the MAIN world and can only reach the extension through postMessage.
window.addEventListener('message', (event) => {
  if (event.source !== window || event.data?.source !== 'flow-recorder-api') return;
  chrome.runtime.sendMessage({ type: 'API_CAPTURE', detail: event.data.detail }).catch(() => {});
});

if (document.documentElement.hasAttribute('data-flow-recorder-hook')) {
  chrome.runtime.sendMessage({ type: 'API_HOOK_READY' }).catch(() => {});
}

// Shows a shrinking countdown so the user knows exactly when "Capture in 5s" will fire, even after
// the popup has closed and focus has moved to DevTools.
const COUNTDOWN_ID = 'jshotz-countdown';

function showCountdown(seconds) {
  document.getElementById(COUNTDOWN_ID)?.remove();

  const badge = document.createElement('div');
  badge.id = COUNTDOWN_ID;
  badge.style.cssText = [
    'position:fixed', 'top:16px', 'right:16px', 'z-index:2147483647',
    'background:#1a1a2e', 'color:#fff', 'font:600 14px/1.4 system-ui,sans-serif',
    'padding:8px 14px', 'border-radius:999px', 'box-shadow:0 2px 10px rgba(0,0,0,.35)',
    'pointer-events:none', 'display:flex', 'align-items:center', 'gap:8px'
  ].join(';');

  const dot = document.createElement('span');
  dot.style.cssText = 'width:8px;height:8px;border-radius:50%;background:#ff5555;flex:none;';
  const label = document.createElement('span');
  badge.append(dot, label);
  document.documentElement.append(badge);

  let remaining = seconds;
  const tick = () => {
    label.textContent = remaining > 0 ? `Capturing in ${remaining}s\u2026` : 'Capturing\u2026';
    if (remaining <= 0) {
      setTimeout(() => badge.remove(), 400);
      return;
    }
    remaining -= 1;
    setTimeout(tick, 1000);
  };
  tick();
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === 'SHOW_COUNTDOWN') showCountdown(message.seconds);
});
